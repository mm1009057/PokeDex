﻿using System;

using PokeDex.ViewModels;
using System.Net.Http;
using System.Net.NetworkInformation;
using System.Threading.Tasks;
using Windows.ApplicationModel.Contacts;
using Windows.Media.Protection;
using Windows.UI.Xaml.Controls;
using Newtonsoft.Json;
using System.Security.Cryptography.X509Certificates;
using Newtonsoft.Json.Linq;
using Windows.UI.Xaml.Media.Imaging;
using System.Collections.ObjectModel;
using System.Collections.Generic;
using Windows.UI.Xaml.Shapes;

namespace PokeDex.Views
{
    public sealed partial class MainPage : Page
    {
        public static Pokemon DisplayedPokemon { get; set; }
        public MainViewModel ViewModel { get; } = new MainViewModel();
        public Pokemon Pokemon { get; set; }
        public MainPage()
        {
            DataContext = this;
            InitializeComponent();
            if (DisplayedPokemon != null)
            {
                MainPage_MoreInfo(DisplayedPokemon);
            }
        }

        public static ObservableCollection<Pokemon> listOfPokemon = new ObservableCollection<Pokemon>();
        public static ObservableCollection<Pokemon> ListOfPokemon
        {
            get { return listOfPokemon; }
            set { listOfPokemon = value; }
        }

        private async void SubmitButton_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            string submitText = PokemonSearchBox.Text;
            submitText = submitText.Replace(" ", string.Empty);
            if (string.IsNullOrEmpty(submitText) == false)
            {
                await MainPage_CreatePokemon();
                PokemonSearchBox.Text = string.Empty;
                PokemonSearchBox.PlaceholderText = "Pokemon name/ID";
            }
            else
            {
                PokemonSearchBox.Text = string.Empty;
                PokemonSearchBox.PlaceholderText = "Please enter a Pokemon name/ID";
            }
        }

        private void MoreInfo_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            if (DisplayedPokemon != null)
            {
                Frame.Navigate(typeof(PokemonInformationPage));
            }
        }
        public async Task MainPage_CreatePokemon()
        {
            string submitText = PokemonSearchBox.Text;
            SubmitInput.PokemonSearchBoxInput = (submitText).ToLower();
            CreatePokemon createPokemon = new CreatePokemon();
            Pokemon newpokemon = await createPokemon.Create();
            if (newpokemon != null)
            {
                MainPage_MoreInfo(newpokemon);
                DisplayedPokemon = newpokemon;

                return;
            }
        }
        public void MainPage_MoreInfo(Pokemon newpokemon)
        {
            DisplayPokemonName.Text = newpokemon.Name;
            PokemonImage.Source = new BitmapImage(new Uri(newpokemon.Sprite));
        }
    }
}
