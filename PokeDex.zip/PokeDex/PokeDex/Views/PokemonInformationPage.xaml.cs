﻿using Newtonsoft.Json.Linq;
using PokeDex.ViewModels;
using System;
using System.Collections.Generic;
using System.Net.Http;
using System.Threading.Tasks;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Media.Imaging;

namespace PokeDex.Views
{
    public sealed partial class PokemonInformationPage : Page
    {
        public PokemonInformationViewModel ViewModel { get; } = new PokemonInformationViewModel();

        public PokemonInformationPage()
        {
            InitializeComponent();
            MoreInfoPage_DisplayInfo();
        }

        public async void MoreInfoPage_DisplayInfo()
        {
            Pokemon newpokemon = MainPage.DisplayedPokemon;

            DisplayPokemonID.Text = newpokemon.ID.ToString();
            DisplayPokemonName.Text = newpokemon.Name;
            DisplayPokemonHeight.Text = $"{newpokemon.Height}m";
            DisplayPokemonWeight.Text = $"{newpokemon.Weight}kg";
            DisplayPokemonColor.Text = newpokemon.Color;
            DisplayPokemonHappy.Text = $"{newpokemon.Happiness} / 255";
            DisplayPokemonType.Text = newpokemon.Type;
            DisplayPokemonEggGroup.Text = newpokemon.EggGroup;
            DisplayPokemonShape.Text = newpokemon.Shape;
            DisplayPokemonCapture.Text = $"{newpokemon.CaptureRate.ToUpper()} / 255";
            DisplayPokemonRelease.Text = newpokemon.Introduced;
            DisplayPokemonImage.Source = new BitmapImage(new Uri(newpokemon.Sprite));

            await DisplayEvolutionChain(newpokemon);
        }

        private async Task DisplayEvolutionChain(Pokemon pokemon)
        {
            try
            {
                string urlEvolution = $"https://pokeapi.co/api/v2/pokemon-species/{pokemon.ID}";
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(urlEvolution);
                string jsonResponseEvolution = await response.Content.ReadAsStringAsync();
                JObject evolutionInfo = JObject.Parse(jsonResponseEvolution);
                string evolutionChainUrl = evolutionInfo["evolution_chain"]["url"].ToString();

                HttpResponseMessage evolutionResponse = await client.GetAsync(evolutionChainUrl);
                string evolutionChainResponse = await evolutionResponse.Content.ReadAsStringAsync();
                JObject evolutionChainInfo = JObject.Parse(evolutionChainResponse);

                List<string> evolutionNames = new List<string>();
                JObject currentEvolution = (JObject)evolutionChainInfo["chain"];

                while (currentEvolution != null)
                {
                    string name = currentEvolution["species"]["name"].ToString();
                    evolutionNames.Add(name);

                    JArray evolvesTo = (JArray)currentEvolution["evolves_to"];
                    currentEvolution = evolvesTo.Count > 0 ? (JObject)evolvesTo[0] : null;
                }


                if (evolutionNames.Count > 0)
                {
                    BaseSprite.Source = await GetPokemonImage(evolutionNames[0]);
                }
                if (evolutionNames.Count > 1)
                {
                    Evo1Sprite.Source = await GetPokemonImage(evolutionNames[1]);
                }
                if (evolutionNames.Count > 2)
                {
                    Evo2Sprite.Source = await GetPokemonImage(evolutionNames[2]);
                }
            }
            catch (Exception e)
            {
                Console.WriteLine($"Evolution Line Error: {e.Message}");
            }
        }

        private async Task<BitmapImage> GetPokemonImage(string pokemonName)
        {
            try
            {
                string url = $"https://pokeapi.co/api/v2/pokemon/{pokemonName}";
                HttpClient client = new HttpClient();
                HttpResponseMessage response = await client.GetAsync(url);
                string jsonResponse = await response.Content.ReadAsStringAsync();

                JObject pokemonData = JObject.Parse(jsonResponse);
                string spriteUrl = pokemonData["sprites"]["other"]["official-artwork"]["front_default"].ToString();

                return new BitmapImage(new Uri(spriteUrl));
            }
            catch
            {
                return null;
            }
        }

        private void Button_Click(object sender, Windows.UI.Xaml.RoutedEventArgs e)
        {
            Frame.Navigate(typeof(MainPage));
        }
    }
}

