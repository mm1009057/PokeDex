﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Windows.UI.Composition;
using System.Net.NetworkInformation;
using Newtonsoft.Json.Linq;

namespace PokeDex
{
    public class Pokemon
    {
        public int ID { get; set; }
        public string Name { get; set; }
        public int Base_experience { get; set; }
        public int Height { get; set; }
        public int Weight { get; set; }
        public string Color { get; set; }
        public int Happiness { get; set; }
        public string Sprite { get; set; }
        public string Type { get; set; }
        public string EggGroup { get; set; }
        public string Shape { get; set; }
        public string CaptureRate { get; set; }
        public string Introduced { get; set; }
    }
}
