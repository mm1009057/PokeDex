﻿using System;

using Microsoft.Toolkit.Mvvm.ComponentModel;

namespace PokeDex.ViewModels
{
    public class PokemonInformationViewModel : ObservableObject
    {
        public PokemonInformationViewModel()
        {
        }
    }
}
