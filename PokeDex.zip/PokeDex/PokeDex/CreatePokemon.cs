﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.Http;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using Windows.UI.Xaml.Media.Imaging;
using PokeDex;

namespace PokeDex
{
    public class CreatePokemon
    {
        public async Task<Pokemon> Create()
        {
            try
            {
                string nameOrID = SubmitInput.PokemonSearchBoxInput;
                HttpClient client = new HttpClient();

                string url = $"https://pokeapi.co/api/v2/pokemon/{nameOrID}";
                HttpResponseMessage response = await client.GetAsync(url);
                string jsonResponse = await response.Content.ReadAsStringAsync();

                string urlSpecies = $"https://pokeapi.co/api/v2/pokemon-species/{nameOrID}";
                HttpResponseMessage responseSpecies = await client.GetAsync(urlSpecies);
                string jsonResponseSpecies = await responseSpecies.Content.ReadAsStringAsync();

                Pokemon newpokemon = JsonConvert.DeserializeObject<Pokemon>(jsonResponse);
                JObject pokemonData = JObject.Parse(jsonResponse);
                JObject pokemonSpeciesData = JObject.Parse(jsonResponseSpecies);

                newpokemon.Name = newpokemon.Name.ToUpper();
                newpokemon.Height = newpokemon.Height / 10;
                newpokemon.Weight = newpokemon.Weight / 10;
                newpokemon.Color = pokemonSpeciesData["color"]["name"].ToString().ToUpper();
                newpokemon.Happiness = Convert.ToInt32(pokemonSpeciesData["base_happiness"]);
                newpokemon.Type = pokemonData["types"][0]["type"]["name"].ToString().ToUpper();
                newpokemon.EggGroup = pokemonSpeciesData["egg_groups"][0]["name"].ToString().ToUpper();
                newpokemon.Shape = pokemonSpeciesData["shape"]["name"].ToString().ToUpper();
                newpokemon.CaptureRate = pokemonSpeciesData["capture_rate"].ToString().ToUpper();
                newpokemon.Introduced = pokemonSpeciesData["generation"]["name"].ToString().ToUpper();

                string spriteUrl = pokemonData["sprites"]["other"]["official-artwork"]["front_default"].ToString();
                newpokemon.Sprite = spriteUrl.ToString();

                return newpokemon;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
    }

}

